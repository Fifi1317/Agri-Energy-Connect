﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agri_Energy_Connect.Controllers
{
    [Authorize]
    public class EnergyController : Controller
    {
        public IActionResult Report()
        {
            return View();
        }
    }
}

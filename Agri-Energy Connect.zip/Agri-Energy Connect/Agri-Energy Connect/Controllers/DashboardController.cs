﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agri_Energy_Connect.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        public IActionResult Index() => View();

        [Authorize(Roles = "Admin")]
        public IActionResult Admin() => View();

        [Authorize(Roles = "Employee")]
        public IActionResult Employee() => View();

        public IActionResult EnergyReport() => View();
        public IActionResult IrrigationSettings() => View();
        public IActionResult Analytics() => View();
        public IActionResult Calendar() => View();
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agri_Energy_Connect.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        public IActionResult Users()
        {
            // List/manage users
            return View();
        }

        public IActionResult Roles()
        {
            // Manage roles/permissions
            return View();
        }

        public IActionResult Logs()
        {
            // View system logs/audit trails
            return View();
        }
    }
}

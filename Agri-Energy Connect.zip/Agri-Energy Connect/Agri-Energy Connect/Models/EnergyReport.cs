﻿namespace Agri_Energy_Connect.Models
{
    public class EnergyReport
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public double EnergyUsedKWh { get; set; }
        public string Notes { get; set; }
    }
}

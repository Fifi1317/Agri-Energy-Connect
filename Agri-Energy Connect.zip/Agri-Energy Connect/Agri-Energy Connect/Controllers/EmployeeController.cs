﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agri_Energy_Connect.Controllers
{
    [Authorize(Roles = "Employee")]
    public class EmployeeController : Controller
    {
        public IActionResult Reports()
        {
            // View and submit daily reports
            return View();
        }

        public IActionResult Support()
        {
            // Support dashboard for farmer queries
            return View();
        }
    }
}

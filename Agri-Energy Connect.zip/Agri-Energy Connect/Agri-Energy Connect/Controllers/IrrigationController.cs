﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Agri_Energy_Connect.Controllers
{
    [Authorize]
    public class IrrigationController : Controller
    {
        public IActionResult Settings()
        {
            return View();
        }
    }
}

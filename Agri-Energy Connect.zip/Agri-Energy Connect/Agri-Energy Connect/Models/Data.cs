﻿using Microsoft.EntityFrameworkCore;
using Agri_Energy_Connect.Models;

namespace Agri_Energy_Connect.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Example DB sets
        public DbSet<Event> Events { get; set; }
        //public DbSet<UserProfile> UserProfiles { get; set; }
        //public DbSet<IrrigationSchedule> IrrigationSchedules { get; set; }
    }
}

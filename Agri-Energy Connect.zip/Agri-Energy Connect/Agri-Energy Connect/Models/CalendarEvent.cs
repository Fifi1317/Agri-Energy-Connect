﻿using System;

namespace Agri_Energy_Connect.Models
{
    public class CalendarEvent
    {
        public string Id { get; set; }           // Unique ID for each event
        public string Title { get; set; }        // Event title
        public DateTime Start { get; set; }      // Start date/time
        public DateTime? End { get; set; }       // (Optional) End date/time
        public string Color { get; set; }        // (Optional) Color for styling
        public bool AllDay { get; set; }         // True for all-day events
    }
}
